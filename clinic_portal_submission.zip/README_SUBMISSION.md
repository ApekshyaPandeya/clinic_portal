# Clinic Management Portal - Assignment Submission

## Project Overview
A fully functional PHP + MySQL Clinic Management System featuring Role-Based Access Control (RBAC), secure CRUD operations, and AJAX-driven live validation.

## Features Implemented
1.  **Authentication & RBAC**:
    *   Secure Login/Logout.
    *   Role-Based Dashboards (Admin vs. Patient/User).
2.  **Full CRUD Functionality**:
    *   **Doctors**: Add, View, Edit, Delete specialists.
    *   **Patients**: Add, View, Edit, Delete medical profiles.
    *   **Appointments**: Book and manage health visits.
    *   **Medications**: Prescribe and track dosage/frequency.
3.  **Search Functionality**:
    *   Standard search for records.
    *   **Live AJAX Autocomplete** for medication searches.
4.  **Ajax Integration (Mandatory 4.5)**:
    *   **Live Username Availability**: Checks database in real-time during registration.
    *   **Medication Search**: Fetches data without page reload in the admin panel.
5.  **Security Measures**:
    *   **SQL Injection Prevention**: Using PDO and Prepared Statements across all queries.
    *   **XSS Prevention**: Proper output escaping using `htmlspecialchars()`.
    *   **CSRF Protection**: Token validation on all POST requests (Registration, Login, Add/Edit forms).
6.  **Advanced UI**: Modern, professional light theme using Inter typography and responsive design.

## Login Credentials
*   **Admin**: `admin` / `password123`
*   **User (Sample)**: `patient1` / `password123`

## Setup Instructions
1.  Import the `database.sql` file into your MySQL database (e.g., via phpMyAdmin).
2.  Update the database credentials in `config/db.php` if necessary.
3.  Place the project folder in your server root (e.g., `htdocs`).
4.  Access the landing page via `index.php`.

## Folder Structure
*   `assets/`: CSS styles and images.
*   `config/`: Database connection settings.
*   `includes/`: Reusable functions and auth checks.
*   `public/`: All public-facing pages (CRUD, Search, Dashboard).
