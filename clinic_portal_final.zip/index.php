<?php
// index.php
header("Location: public/index.php");
exit();
?>